import { BookFormErrorMessages } from './book-form-error-messages';

describe('BookFormErrorMessages', () => {
  it('should create an instance', () => {
    expect(new BookFormErrorMessages()).toBeTruthy();
  });
});
